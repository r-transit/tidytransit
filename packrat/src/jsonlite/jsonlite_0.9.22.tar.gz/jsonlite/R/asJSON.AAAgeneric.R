setGeneric("asJSON", function(x, ...) {
  standardGeneric("asJSON")
})
